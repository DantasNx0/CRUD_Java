/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidade;


import controle.Produto;
import controle.Usuario;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.ResultSet;
/**
 *
 * @author joao
 */
public class ManterUsuario extends DAO{
    
    public void addUsuario(Usuario usuario) throws Exception{
        try {
            abrirBanco();
            String query = "INSERT INTO usuario(id,nome,email)"
                    + "values(null,?,?)";
            
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, usuario.getNome());
            pst.setString(2, usuario.getEmail());
            pst.execute();
            fecharBanco();
            
        } catch (Exception e) {
            System.out.println("Eroo:" + e.getMessage());
        }
        
    }
    
    public void addProduto(Produto produto) throws Exception{
    
        try {
            
            abrirBanco();
            String query = "INSERT INTO produto(id,nome,preco)"
                    + "VALUES(null,?,?)";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, produto.getNome());
            pst.setDouble(2, produto.getPreco());
            pst.execute();
            fecharBanco();
            
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    
    }
    
    public void removerUsuario(String nomeUsuario) throws Exception{
        
        try {
            
            abrirBanco();
            String query = "DELETE from usuario where nome=?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, nomeUsuario);
            pst.execute();
            fecharBanco();
            
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
            
        }
        
    }
    
    public void removerProduto(String nomeProduto) throws Exception{
        
        try {
            
            abrirBanco();
            String query = "DELETE from produto where nome=?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, nomeProduto);
            pst.execute();
            fecharBanco();
            
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
            
        }
    }
    
    
    public void alterarUsuario(String nomeAntigo, String novoNome) throws Exception{
        try {
            abrirBanco();
            String query = "UPDATE usuario SET nome = ? WHERE nome = ?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, novoNome);
            pst.setString(2, nomeAntigo);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    }
    
    public void alterarUsuarioEmail(String nome, String emailNovo) throws Exception{
        try {
            abrirBanco();
            String query = "UPDATE usuario SET email = ? WHERE nome = ?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, emailNovo);
            pst.setString(2, nome);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    }
    
    
    public void alterarProduto(String nomeAntigo, String novoNome) throws Exception{
        try {
            abrirBanco();
            String query = "UPDATE produto SET nome = ? WHERE nome = ?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, novoNome);
            pst.setString(2, nomeAntigo);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    }
    
    
    public void alterarProdutoPreco(String nome, double preco) throws Exception{
        try {
            abrirBanco();
            String query = "UPDATE produto SET preco = ? WHERE nome = ?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setDouble(1, preco);
            pst.setString(2, nome);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    }
    
    
    public void vincularProduto(String nome, String produto)throws Exception{
        try {
            abrirBanco();
            String query = "INSERT INTO UsuarioProduto (nome_usuario, nome_produto) VALUES (?,?);";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, nome);
            pst.setString(2, produto);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    }
    
    public void desvincular(String nome, String produto)throws Exception{
        try {
            abrirBanco();
            String query = "DELETE FROM UsuarioProduto " +
                "WHERE nome_usuario = ? AND nome_produto = ?;";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setString(1, nome);
            pst.setString(2, produto);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
    }
    
    
    public ArrayList<Usuario> PesquisarUsuario() throws Exception{
        ArrayList<Usuario> usuarios = new ArrayList();
        try {
            abrirBanco();
            String query = "SELECT id, nome, email FROM usuario";
            pst = (PreparedStatement) con.prepareStatement(query);
            ResultSet tr = pst.executeQuery();
            Usuario u;
            while(tr.next()){
                u = new Usuario();
                u.setId(tr.getInt("id"));
                u.setNome(tr.getString("nome"));
                u.setEmail(tr.getString("email"));
                usuarios.add(u);
            }
            fecharBanco();        
                    
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
        return usuarios;
    }
    
    
    public ArrayList<Produto> PesquisarProduto() throws Exception{
        ArrayList<Produto> produto = new ArrayList();
        try {
            abrirBanco();
            String query = "SELECT id, nome, preco FROM produto";
            pst = (PreparedStatement) con.prepareStatement(query);
            ResultSet tr = pst.executeQuery();
            Produto p;
            while(tr.next()){
                p = new Produto();
                p.setId(tr.getInt("id"));
                p.setNome(tr.getString("nome"));
                p.setPreco(tr.getDouble("preco"));
                produto.add(p);
            }
            fecharBanco();        
                    
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
        return produto;
    }
    
    
    public ArrayList<Produto> pesquisarProdutosPorUsuario(String nomeUsuario) throws Exception {
    ArrayList<Produto> produtos = new ArrayList<>();
    try {
        abrirBanco();
        String query = "SELECT Produto.* " +
                       "FROM Produto " +
                       "JOIN UsuarioProduto ON Produto.nome = UsuarioProduto.nome_produto " +
                       "WHERE UsuarioProduto.nome_usuario = ?";
        pst = (PreparedStatement) con.prepareStatement(query);
        pst.setString(1, nomeUsuario);
        
        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setPreco(rs.getDouble("preco"));
                produtos.add(produto);
            }
        }
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            fecharBanco();
        }
        return produtos;
    }
    

    
}
